#ifndef __SWITCHES_H__
#define __SWITCHES_H__

#include "isr_switch.h"

#define OPEN_SW_PIN       (34)
#define CLOSE_SW_PIN      (35)
#define SW_ON_LEVEL       (HIGH)
#define TIMER_NUM_OPEN    (0)
#define TIMER_NUM_CLOSE   (1)
#define CHATTER_TIME_MS   (30)

typedef enum
{
  SW_ON,
  SW_OFF,
} SwState_t;

typedef struct
{
  IsrSwitch* pSwitch;
  volatile SwState_t state;
  volatile bool  turnOn;
  hw_timer_t* pTimer;
} Switch_t;


void InitSwitches(void);
bool CheckOpenSwTurnOn(void);
bool CheckCloseSwTurnOn(void);

#endif  /* __SWITCHES_H__ */
