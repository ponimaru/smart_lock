#ifndef __USER_H__
#define __USER_H__

#include <Arduino.h>

#define UID_BYTE_SIZE (8)
#define USER_BYTE_SIZE  (4)
#define USER_HASH_SIZE  (4)

typedef struct
{
  uint8_t piccType;
  uint8_t uidSize;
  byte uid[UID_BYTE_SIZE];
  byte uData[USER_BYTE_SIZE];
  String uName;
} User_t;

uint8_t GetUserNumber(void);
bool IsMatchPiccType(uint8_t num, uint8_t piccType);
bool IsMatchUid(uint8_t num, uint8_t uidSize, byte* uid);
bool IsMatchUserData(uint8_t num, byte* hash);
String GetUserName(uint8_t num);
unsigned int GetHash(uint8_t num);

#endif
