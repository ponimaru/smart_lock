#ifndef __LED_H__
#define __LED_H__

#include "Arduino.h"

class Led
{
  private:
    uint8_t pin;
    uint8_t on_level;

  public:
    Led(uint8_t pin, uint8_t on_level);
    void On(void);
    void Off(void);
    uint8_t GetState(void);
};

#endif  /* __LED_H__ */
