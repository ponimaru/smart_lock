#ifndef __PRINT_H__
#define __PRINT_H__

#include <Arduino.h>

void printHex(byte *buffer, byte bufferSize);
void printDec(byte *buffer, byte bufferSize);

#endif  /* __PRINT_H__ */
