#include "rc522.h"

Rc522::Rc522(uint8_t pin_ss, uint8_t pin_rst)
{
  SPI.begin();
  this->pRc522 = new MFRC522(pin_ss, pin_rst);
  this->pRc522->PCD_Init();

  for (byte i = 0; i < 6; i++)
  {
    this->key.keyByte[i] = 0xFF;
  }
};

bool Rc522::IsDetect(void)
{
  if (!this->pRc522->PICC_IsNewCardPresent() || ! this->pRc522->PICC_ReadCardSerial())
  {
    return false;
  }
  else
  {
    return true;
  }
};

MFRC522::PICC_Type Rc522::GetReadPiccType(void)
{
  return this->pRc522->PICC_GetType(this->pRc522->uid.sak);
};

uint8_t Rc522::GetReadUidSize(void)
{
  return this->pRc522->uid.size;
}

byte* Rc522::GetReadUid(void)
{
  return this->pRc522->uid.uidByte;
};

bool Rc522::GetUserData(byte block, byte* pBuffer, byte len)
{
  byte buffer[18];
  byte block_len = 18;
  MFRC522::StatusCode status;

  status = this->pRc522->MIFARE_Read(block, buffer, &block_len);
  if(status == MFRC522::STATUS_OK)
  {
    Serial.print("Read User Data : ");
    printHex(buffer, len);
    for (volatile uint8_t i = 0; i < len; i++)
    {
      pBuffer[i] = buffer[i];
    }
    return true;
  }
  else
  {
    Serial.println(this->pRc522->GetStatusCodeName(status));
    return false;
  }
};

bool Rc522::WriteUserData(byte block, byte* pBuffer, byte len)
{
  byte buffer[16] = {0};
  byte block_len = 16;
  MFRC522::StatusCode status;
  MFRC522::MIFARE_Key key;

  for (volatile uint8_t i = 0; i < len; i++)
  {
    buffer[i] = pBuffer[i];
  }

  switch(this->GetReadPiccType())
  {
    /* MIFARE 1KB */
    case 4:
      for (byte i = 0; i < 6; i++)
      {
        key.keyByte[i] = 0xFF;
      }
      
      status = this->pRc522->PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, block, &key, &(this->pRc522->uid));
      if (status != MFRC522::STATUS_OK)
      {
        Serial.print(F("PCD_Authenticate() failed: "));
        Serial.println(this->pRc522->GetStatusCodeName(status));
        return false;
      }

      status = this->pRc522->MIFARE_Write(block, buffer, block_len);
      if(status == MFRC522::STATUS_OK)
      {
        Serial.print("Wrote User Data : ");
        printHex(buffer, len);
        return true;
      }
      else
      {
        Serial.println(this->pRc522->GetStatusCodeName(status));
        return false;
      }
      break;

    /* Ultralight */
    case 6:
      status = this->pRc522->MIFARE_Write(block, buffer, block_len);
      if(status == MFRC522::STATUS_OK)
      {
        Serial.print("Wrote User Data : ");
        printHex(buffer, len);
        return true;
      }
      else
      {
        Serial.println(this->pRc522->GetStatusCodeName(status));
        return false;
      }
      break;

    default:
      break;
  }
};

void Rc522::DumpToSerial(void)
{
  this->pRc522->PICC_DumpToSerial(&(this->pRc522->uid));
}

void Rc522::Halt(void)
{
  this->pRc522->PICC_HaltA();
};
