#include "user.h"

const static User_t userData[] = 
{
  /* User : Master */
  [0] = {.piccType = 6, .uidSize = 7, .uid = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07}, .uData = {0x12, 0x34, 0x56, 0x78}, .uName = "Master"},

  /* User : Tester */
  [1] = {.piccType = 6, .uidSize = 7, .uid = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x08}, .uData = {0xAA, 0xBB, 0xCC, 0xDD}, .uName = "Tester"},
};

uint8_t GetUserNumber(void)
{
  return (sizeof(userData) / sizeof(User_t));
}

bool IsMatchPiccType(uint8_t num, uint8_t piccType)
{
  if(userData[num].piccType == piccType)
  {
    return true;
  }
  else
  {
    return false;
  }
}

bool IsMatchUid(uint8_t num, uint8_t uidSize, byte* uid)
{
  if(userData[num].uidSize == uidSize)
  {
    for(volatile uint8_t i = 0; i < uidSize; i++)
    {
      if(userData[num].uid[i] != uid[i])
      {
        return false; 
      }
    }
    return true;
  }
  else
  {
    return false;
  }
}

bool IsMatchUserData(uint8_t num, byte* hash)
{
  /**
   * Caution: Please implement according to user specifications.
   */
}

String GetUserName(uint8_t num)
{
  return userData[num].uName;
}

unsigned int GetHash(uint8_t num)
{
  /**
   * Caution: Please implement according to user specifications.
   */
}
