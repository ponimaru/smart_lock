#include "sg92r.h"

Sg92r::Sg92r(uint8_t pin_pwr, uint8_t pin_pwm, uint8_t default_degree)
{
  /* Set parameters */
  this->pin_pwr = pin_pwr;
  this->pin_pwm = pin_pwm;
  pinMode(this->pin_pwr, OUTPUT);
  
  this->PowerOn();
  this->servo.setPeriodHertz(50);
  this->servo.attach(this->pin_pwm, MIN_US, MAX_US);
  this->servo.write(default_degree);
  this->PowerOff();
};

void Sg92r::PowerOn(void)
{
  digitalWrite(this->pin_pwr, HIGH);  
};

void Sg92r::PowerOff(void)
{
  digitalWrite(this->pin_pwr, LOW);  
};

uint8_t Sg92r::GetPowerLevel(void)
{
  return digitalRead(this->pin_pwr);
};

uint8_t Sg92r::GetDegree(void)
{
  return this->servo.read();
};

void Sg92r::RotateDegree(uint8_t degree)
{
  int read_degree;
  this->servo.write(degree);

  do
  {
    read_degree = this->servo.read();
  }while(read_degree != degree);
};
