#ifndef __SG92R_H__
#define __SG92R_H__

#include <ESP32Servo.h>

#define MIN_US  (1000)
#define MAX_US  (2000)

class Sg92r
{
  private:
    Servo servo;
    uint8_t pin_pwr;
    uint8_t pin_pwm;

  public:
    Sg92r(uint8_t pin_pwr, uint8_t pin_pwm, uint8_t default_degree);
    void PowerOn(void);
    void PowerOff(void);
    uint8_t GetPowerLevel(void);
    uint8_t GetDegree(void);
    void RotateDegree(uint8_t degree);
};

#endif /* __SG92R_H__ */
