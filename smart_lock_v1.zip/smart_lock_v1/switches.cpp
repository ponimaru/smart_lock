#include "switches.h"

static Switch_t openSw;
static Switch_t closeSw;

static void IRAM_ATTR IsrOpenSwitchOn(void);
static void IRAM_ATTR IsrCloseSwitchOn(void);
static void IRAM_ATTR IsrOpenChatterTime(void);
static void IRAM_ATTR IsrCloseChatterTime(void);

void InitSwitches(void)
{
  openSw.pSwitch = new IsrSwitch(OPEN_SW_PIN, SW_ON_LEVEL, IsrOpenSwitchOn, NULL);
  openSw.pSwitch->EnableOnInterrupt();
  openSw.state = SW_OFF;
  openSw.turnOn = false;
  openSw.pTimer = timerBegin(TIMER_NUM_OPEN, getApbFrequency()/1000000, true);
  timerAttachInterrupt(openSw.pTimer, &IsrOpenChatterTime, true);
  timerAlarmWrite(openSw.pTimer, CHATTER_TIME_MS * 1000, false);
  
  closeSw.pSwitch = new IsrSwitch(CLOSE_SW_PIN, SW_ON_LEVEL, IsrCloseSwitchOn, NULL);
  closeSw.pSwitch->EnableOnInterrupt();
  closeSw.state = SW_OFF;
  closeSw.turnOn = false;
  closeSw.pTimer = timerBegin(TIMER_NUM_CLOSE, getApbFrequency()/1000000, true);
  timerAttachInterrupt(closeSw.pTimer, &IsrCloseChatterTime, true);
  timerAlarmWrite(closeSw.pTimer, CHATTER_TIME_MS * 1000, false);
}

bool CheckOpenSwTurnOn(void)
{
  bool flag = openSw.turnOn;

  openSw.turnOn = false;

  return flag;
}

bool CheckCloseSwTurnOn(void)
{
  bool flag = closeSw.turnOn;

  closeSw.turnOn = false;

  return flag;
}

static void IRAM_ATTR IsrOpenSwitchOn(void)
{
  openSw.pSwitch->DisableInterrupt();
  timerAlarmEnable(openSw.pTimer);
}

static void IRAM_ATTR IsrCloseSwitchOn(void)
{
  closeSw.pSwitch->DisableInterrupt();
  timerAlarmEnable(closeSw.pTimer);
}

static void IRAM_ATTR IsrOpenChatterTime(void)
{
  timerAlarmDisable(openSw.pTimer);
  openSw.pSwitch->EnableOnInterrupt();
  if (openSw.pSwitch->GetLevel() == SW_ON_LEVEL)
  {
    openSw.state = SW_ON;
    openSw.turnOn = true;
  }
  else
  {
    openSw.state = SW_OFF;
  }
}

static void IRAM_ATTR IsrCloseChatterTime(void)
{
  timerAlarmDisable(closeSw.pTimer);
  closeSw.pSwitch->EnableOnInterrupt();
  if (closeSw.pSwitch->GetLevel() == SW_ON_LEVEL)
  {
    closeSw.state = SW_ON;
    closeSw.turnOn = true;
  }
  else
  {
    closeSw.state = SW_OFF;
  }
}
