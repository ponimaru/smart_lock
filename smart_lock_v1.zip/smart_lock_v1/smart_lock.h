#ifndef __SMART_LOCK_H__
#define __SMART_LOCK_H__

#include <SPI.h>
#include <MFRC522.h>
#include "sg92r.h"
#include "switches.h"
#include "led.h"
#include "rc522.h"
#include "user.h"
#include "print.h"

#define SERVO_PWR_PIN     (12)
#define SERVO_PWM_PIN     (27)
#define RC522_SS_PIN      (5)
#define RC522_SCK_PIN     (18)
#define RC522_MOSI_PIN    (23)
#define RC522_MISO_PIN    (19)
#define RC522_RST_PIN     (26)
#define RC522_IRQ_PIN     (22)

#define OPEN_LED_PIN      (32)
#define CLOSE_LED_PIN     (33)
#define SUCCESS_LED_PIN   (17)
#define FAIL_LED_PIN      (16)

#define LOCK_STATE_OPEN   (true)
#define LOCK_STATE_CLOSE  (false)

#define OPEN_DEGREE       (0)
#define CLOSE_DEGREE      (180)

#define TIMER_NUM_PROHIBIT (2)
#define PROHIBIT_TIME_MS  (500)
#define WAIT_TIME_MS      (10000)

typedef enum
{
  MODE_NORMAL = 0,
  MODE_WRITE = 1,
} opeMode_t;

typedef struct
{
  Sg92r* pMotor;
  Rc522 * pRc522;
  Led* pOpenLed;
  Led* pCloseLed;
  Led* pSuccessLed;
  Led* pFailLed;
  hw_timer_t* pProhibitTimer;
  volatile bool prohibitFlag;
  mode_t mode;
} smart_lock_t;

void InitSmartLock(void);
void SwitchProcess(void);
void RfidProcess(void);

#endif  /* __SMART_LOCK_H__ */
