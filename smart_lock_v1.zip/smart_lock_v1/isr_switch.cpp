#include "isr_switch.h"

IsrSwitch::IsrSwitch(uint8_t pin, uint8_t onLevel, IsrSwitchEdge pOnCallback, IsrSwitchEdge pOffCallback)
{
  this->pin = pin;
  this->onLevel = onLevel;
  this->pOnCallback = pOnCallback;
  this->pOffCallback = pOffCallback;

  pinMode(this->pin, INPUT);
  this->DisableInterrupt();
};

uint8_t IsrSwitch::GetLevel(void)
{
  return digitalRead(this->pin);
}

void IsrSwitch::EnableOnInterrupt(void)
{
  if (this->pOnCallback != NULL)
  {
    if (this->onLevel == HIGH)
    {
      attachInterrupt(digitalPinToInterrupt(this->pin), this->pOnCallback, RISING);
      gpio_wakeup_enable((gpio_num_t)this->pin, GPIO_INTR_HIGH_LEVEL);
    }
    else
    {
      attachInterrupt(digitalPinToInterrupt(this->pin), this->pOnCallback, FALLING);
      gpio_wakeup_enable((gpio_num_t)this->pin, GPIO_INTR_LOW_LEVEL);
    }
    esp_sleep_enable_gpio_wakeup();
  }
};

void IsrSwitch::EnableOffInterrupt(void)
{
  if (this->pOffCallback != NULL)
  {
    if (this->onLevel == HIGH)
    {
      attachInterrupt(digitalPinToInterrupt(this->pin), this->pOffCallback, FALLING);
      gpio_wakeup_enable((gpio_num_t)this->pin, GPIO_INTR_LOW_LEVEL);
    }
    else
    {
      attachInterrupt(digitalPinToInterrupt(this->pin), this->pOffCallback, RISING);
      gpio_wakeup_enable((gpio_num_t)this->pin, GPIO_INTR_HIGH_LEVEL);
    }
    esp_sleep_enable_gpio_wakeup();
  }
};

void IsrSwitch::DisableInterrupt(void)
{
  detachInterrupt(digitalPinToInterrupt(this->pin));
  gpio_wakeup_disable((gpio_num_t)this->pin);

};
