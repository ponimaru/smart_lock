#include "led.h"

Led::Led(uint8_t pin, uint8_t on_level)
{
  this->pin = pin;
  this->on_level = on_level;

  pinMode(this->pin, OUTPUT);
  this->Off();
};

void Led::On(void)
{
  digitalWrite(this->pin, on_level);
};

void Led::Off(void)
{
  digitalWrite(this->pin, !on_level);  
};

uint8_t Led::GetState(void)
{
  return digitalRead(this->pin);
}
