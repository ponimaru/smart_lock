#include "smart_lock.h"

static smart_lock_t smart_lock;
static uint8_t user_num;

static void OpenLock(void);
static void CloseLock(void);
static void BlinkOpenLed(void);
static void BlinkCloseLed(void);
static void IRAM_ATTR IsrProhibitTimer(void);

void InitSmartLock(void)
{
  user_num = GetUserNumber();

  /* Init Switches */
  InitSwitches();

  /**
   * Normal Mode
   */
  if((digitalRead(OPEN_SW_PIN) != SW_ON_LEVEL)
  || (digitalRead(CLOSE_SW_PIN) != SW_ON_LEVEL))
  {
    Serial.println("Normal Mode");
    smart_lock.mode = MODE_NORMAL;

    /* Init Motor */
    smart_lock.pMotor = new Sg92r(SERVO_PWR_PIN, SERVO_PWM_PIN, CLOSE_DEGREE);
  
    /* Init RC522 */
    smart_lock.pRc522 = new Rc522(RC522_SS_PIN, RC522_RST_PIN);
  
    /* Init LEDs */
    smart_lock.pOpenLed = new Led(OPEN_LED_PIN, LOW);
    smart_lock.pCloseLed = new Led(CLOSE_LED_PIN, LOW);
    smart_lock.pSuccessLed = new Led(SUCCESS_LED_PIN, HIGH);
    smart_lock.pFailLed = new Led(FAIL_LED_PIN, HIGH);

    /* Init Prohibit Timer */
    smart_lock.prohibitFlag = false;
    smart_lock.pProhibitTimer = timerBegin(TIMER_NUM_PROHIBIT, getApbFrequency()/1000000, true);
    timerAttachInterrupt(smart_lock.pProhibitTimer, &IsrProhibitTimer, true);
    timerAlarmWrite(smart_lock.pProhibitTimer, PROHIBIT_TIME_MS * 1000, true);
  }
  /**
   * Write Mode
   */
  else
  {
    Serial.println("Write Mode");
    smart_lock.mode = MODE_WRITE;
  
    /* Init RC522 */
    smart_lock.pRc522 = new Rc522(RC522_SS_PIN, RC522_RST_PIN);

    /* Init LEDs */
    smart_lock.pSuccessLed = new Led(SUCCESS_LED_PIN, HIGH);
    smart_lock.pFailLed = new Led(FAIL_LED_PIN, HIGH);
  }
}

void SwitchProcess(void)
{
  uint8_t degree;
  
  switch (smart_lock.mode)
  {
    case MODE_NORMAL:
      degree = smart_lock.pMotor->GetDegree();
    
      if ((CheckOpenSwTurnOn() == true) && (smart_lock.prohibitFlag == false))
      {
        if ((smart_lock.pMotor->GetPowerLevel() == LOW) && (degree != OPEN_DEGREE))
        {
          smart_lock.pOpenLed->On();
          OpenLock();
          smart_lock.pOpenLed->Off();
        }
        else
        {
          BlinkOpenLed();
        }
        smart_lock.prohibitFlag = true;
        timerAlarmEnable(smart_lock.pProhibitTimer);
      }
    
      if ((CheckCloseSwTurnOn() == true) && (smart_lock.prohibitFlag == false))
      {
        if ((smart_lock.pMotor->GetPowerLevel() == LOW) && (degree != CLOSE_DEGREE))
        {
          smart_lock.pCloseLed->On();      
          CloseLock();
          smart_lock.pCloseLed->Off();      
        }
        else
        {
          BlinkCloseLed();
        }
        smart_lock.prohibitFlag = true;
        timerAlarmEnable(smart_lock.pProhibitTimer);
      }
      break;

    case MODE_WRITE:
    default:
      break;
  }
}

void RfidProcess(void)
{
  uint8_t piccType;
  uint8_t uidSize;
  byte* uid;
  byte uData[4];
  
  // カードの読み取り確認.
  if (smart_lock.pRc522->IsDetect() == false)
  {
    return;
  }

  piccType = smart_lock.pRc522->GetReadPiccType();
  uidSize = smart_lock.pRc522->GetReadUidSize();
  uid = smart_lock.pRc522->GetReadUid();

  Serial.print("\n");
  Serial.print(F("PICC type: "));
  Serial.println(piccType);

  Serial.print(F("UID: "));
  printHex(uid, uidSize);

  switch(smart_lock.mode)
  {
    case MODE_NORMAL:
      for (volatile uint8_t i = 0; i < user_num; i++)
      {
        if((IsMatchPiccType(i, piccType) == true)
        && (IsMatchUid(i, uidSize, uid) == true))
        {
          if((smart_lock.pRc522->GetUserData(7, uData, 4) == true)
          && (IsMatchUserData(i, uData) == true))
          {
            Serial.print("Detected : ");
            Serial.println(GetUserName(i));
            smart_lock.pSuccessLed->On();
            OpenLock();
            smart_lock.pSuccessLed->Off();
            delay(WAIT_TIME_MS);
            CloseLock();
            return;
          }
        }
      }
      smart_lock.pFailLed->On();
      delay(500);
      smart_lock.pFailLed->Off();
      break;

    case MODE_WRITE:
      for (volatile uint8_t i = 0; i < user_num; i++)
      {
        if((IsMatchPiccType(i, piccType) == true)
        && (IsMatchUid(i, uidSize, uid) == true))
        {
          unsigned int iHash;
          byte bHash[USER_HASH_SIZE];
  
          iHash = GetHash(i);
          bHash[0] = (iHash & 0xFF000000) >> 24;
          bHash[1] = (iHash & 0x00FF0000) >> 16;
          bHash[2] = (iHash & 0x0000FF00) >> 8;
          bHash[3] = (iHash & 0x000000FF);
          
          smart_lock.pRc522->WriteUserData(7, bHash, USER_HASH_SIZE);
          smart_lock.pRc522->DumpToSerial();
          
          smart_lock.pSuccessLed->On();
          delay(300);
          smart_lock.pSuccessLed->Off();
          return;
        }
      }

      /* Blink LED for Fail */
      smart_lock.pFailLed->On();
      delay(300);
      smart_lock.pFailLed->Off();
      
      break;
  }
}

static void OpenLock(void)
{
  Serial.println("Rotate to OPEN");

  smart_lock.pMotor->PowerOn();
  delay(200);
  smart_lock.pMotor->RotateDegree(OPEN_DEGREE);
  delay(200);
  smart_lock.pMotor->PowerOff();
}

static void CloseLock(void)
{
  Serial.println("Rotate to CLOSE");
  
  smart_lock.pMotor->PowerOn();
  delay(200);
  smart_lock.pMotor->RotateDegree(CLOSE_DEGREE);
  delay(200);
  smart_lock.pMotor->PowerOff();
}

static void BlinkOpenLed(void)
{
  smart_lock.pOpenLed->On();
  delay(250);
  smart_lock.pOpenLed->Off();
  delay(250);
  smart_lock.pOpenLed->On();
  delay(250);
  smart_lock.pOpenLed->Off();
}

static void BlinkCloseLed(void)
{
  smart_lock.pCloseLed->On();
  delay(250);
  smart_lock.pCloseLed->Off();
  delay(250);
  smart_lock.pCloseLed->On();
  delay(250);
  smart_lock.pCloseLed->Off();
}


static void IRAM_ATTR IsrProhibitTimer(void)
{
  timerAlarmDisable(smart_lock.pProhibitTimer);
  smart_lock.prohibitFlag = false;
  CheckOpenSwTurnOn();
  CheckCloseSwTurnOn();
}
