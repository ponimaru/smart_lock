#ifndef __RC522_H__
#define __RC522_H__

#include <SPI.h>
#include <MFRC522.h>
#include "print.h"

class Rc522
{
  private:
    MFRC522* pRc522;
    MFRC522::MIFARE_Key key;

  public:
    Rc522(uint8_t pin_ss, uint8_t pin_rst);
    bool IsDetect(void);
    MFRC522::PICC_Type GetReadPiccType(void);
    uint8_t GetReadUidSize(void);
    byte* GetReadUid(void);
    bool GetUserData(byte block, byte* pBuffer, byte len);
    bool WriteUserData(byte block, byte* pBuffer, byte len);
    void DumpToSerial(void);
    void Halt(void);
};

#endif /* __RC522_H__ */
