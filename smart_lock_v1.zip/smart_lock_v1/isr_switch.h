#ifndef __ISR_SWITCH_H__
#define __ISR_SWITCH_H__

#include <Arduino.h>

typedef void (*IsrSwitchEdge)(void);

class IsrSwitch
{
  private:
    uint8_t pin;
    uint8_t onLevel;
    IsrSwitchEdge pOnCallback;
    IsrSwitchEdge pOffCallback;

  public:
    IsrSwitch(uint8_t pin, uint8_t onLevel, IsrSwitchEdge pOnCallback, IsrSwitchEdge pOffCallback);
    uint8_t GetLevel(void);
    void EnableOnInterrupt(void);
    void EnableOffInterrupt(void);
    void DisableInterrupt(void);    
};

#endif /* __ISR_SWITCH_H__ */
